
public class Personas {
	private String nombre;
	private String apellido;
	
	public Personas(String nombre, String apellido) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
	}
	
	@Override
	public String toString() {
		return " [nombre=" + nombre + ", apellido=" + apellido + "]";
	}

	public Personas() {
		super();
		
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public void agregarALista() {
		
	}
	
	public void ordenarPorNombre() {
		
	}
	
	public void ordenarPorApellido() {
		
	}
	public void ordenarInversamente() {
		
	}

 
}
