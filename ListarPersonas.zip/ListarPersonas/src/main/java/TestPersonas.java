import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class TestPersonas {

	public static void main(String[] args) {
		Personas persona1 = new Personas ("Lucia","Corral");
		Personas persona2= new Personas ("Norma", "Manzilo");
		Personas persona3= new Personas("Roberto", "Manzilo");
		Personas persona4= new Personas("Christian", "Manzilo");
		Personas persona5= new Personas("Pepe","Argento");
		
		// el ejercicio no pide mostrar por pantalla la lista pero lo agrego para que se vea mejor
		ArrayList<Personas> listadoPersonas= new ArrayList<>();
		listadoPersonas.add(persona5);
		listadoPersonas.add(persona4);
		listadoPersonas.add(persona3);
		listadoPersonas.add(persona2);
		listadoPersonas.add(persona1);
		System.out.println("Listado de Personas;");
		for (Personas persona : listadoPersonas){
			System.out.println(persona);
			
		}


		//Ordenar lista por nombre A a Z
        Collections.sort(listadoPersonas, Comparator.comparing(Personas::getNombre));// compara los elementos de la lista basandose en lo que trae el metodo en este caso getnombre()
        System.out.println("\nLista ordenada de la A a la Z por nombre:");
        for (Personas persona : listadoPersonas) {
            System.out.println(persona);
        }
        


        // Ordenar la lista por apellido A a Z
        Collections.sort(listadoPersonas, Comparator.comparing(Personas::getApellido));
        System.out.println("\nLista ordenada de la A a la Z por apellido:");
        for (Personas persona : listadoPersonas) {
            System.out.println(persona);
        }

        // Ordenar la lista inversamente por apellido Z a A
        Collections.sort(listadoPersonas, Comparator.comparing(Personas::getApellido).reversed());
        System.out.println("\nLista ordenada de la Z a la A por apellido:");
        for (Personas persona : listadoPersonas) {
            System.out.println(persona);
        }

	}

}
